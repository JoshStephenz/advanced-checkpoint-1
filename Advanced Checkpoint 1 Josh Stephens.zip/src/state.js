export default {
 searchResults: [],
 myMovieList: []
};
